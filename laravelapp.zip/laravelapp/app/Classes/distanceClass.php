<?php

namespace App\Classes;
class distanceClass {
    //put your code here
    private float $lat;
    private float $lonh;   
    public function __construct(float $lat=53.3340285, float $long=-6.2535495) {
        $this->lat = $lat;
        $this->long = $long;
    }
    public function distance(float $lat, float $long) : float
    {
        $deltaLong = $long - $this->long;
        
        // arccos argument
        $a1 = sin(deg2rad($this->lat))*sin(deg2rad($lat));
       
        $a1 += cos(deg2rad($this->lat))*cos(deg2rad($lat))*cos(deg2rad($deltaLong));
        
        //
        $deltaSigma = acos($a1);
        
        $result = 6335.439*$deltaSigma;
        
        return $result;
    }
}
