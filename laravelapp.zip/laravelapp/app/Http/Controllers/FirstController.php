<?php

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use App\Classes\distanceClass;

class FirstController extends Controller
{
    //
    public function index()
    {
        $inputArray = @file("../affiliates-1.txt");
        if($inputArray){
            $d = New distanceClass;
            foreach($inputArray as $a){
                
                $obj = json_decode($a);
                $dist = $d->distance((float)($obj->latitude), (float)($obj->longitude));
                if($dist <= 100.0){
                    $resultArray[(int)$obj->affiliate_id] = 
                            array(
                                "latitude"  => (float)($obj->latitude), 
                                "longitude" => (float)($obj->longitude),
                                "name"      => (string)($obj->name),
                                "distance"   => $dist
                            );
                }
            }
            ksort($resultArray);
            return view('first', [
                'jdata' => $resultArray
            ]);
        } else {
            echo "Error";
            exit;
        }
        
    }
    
}
