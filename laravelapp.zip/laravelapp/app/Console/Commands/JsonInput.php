<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class JsonInput extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'json:input';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // $this->info('Display this on the screen');
        $inputArray = @file("affiliates-1.txt");
        $resultArray =  array();
        if($inputArray){
            // 
            foreach($inputArray as $a){
                
                $obj = json_decode($a);
                $dist = $this->distanse((float)($obj->latitude), (float)($obj->longitude));
                if($dist <= 100.0){
                    $resultArray[(int)$obj->affiliate_id] = 
                            array(
                                "latitude"  => (float)($obj->latitude), 
                                "longitude" => (float)($obj->longitude),
                                "name"      => (string)($obj->name),
                                "distanse"   => $dist
                            );
                }
            }
            ksort($resultArray);
            print_r($resultArray);
        }
        else {
            $this->error('File oes not exists!');
        }
        return Command::SUCCESS;
    }
    private function distanse(float $lat, float $long) : float
    {
        $deltaLong = $long + 6.2535495;
        
        // arccos argument
        $a1 = sin(deg2rad(53.3340285))*sin(deg2rad($lat));
       
        $a1 += cos(deg2rad(53.3340285))*cos(deg2rad($lat))*cos(deg2rad($deltaLong));
        
        //
        $deltaSigma = acos($a1);
        
        $result = 6335.439*$deltaSigma;
        return $result;
    }
}
