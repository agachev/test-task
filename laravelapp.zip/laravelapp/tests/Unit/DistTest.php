<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Classes\distanceClass;

class DistTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function test_example()
    {
        $d = New distanceClass();
        echo $d->distance(51.999447, -9.742744),"\n";
        $this->assertTrue($d->distance(51.999447, -9.742744) > 100.0);
    }
}
