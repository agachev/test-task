
Hi
Start this task using
php artisan serve
Use /first path
I create FirstController
first blade template
and class distance class


Class is rather simple so it no much phpubit test could be done
To temonstrate principle I made TestDist

All files are in standart places

Class is in App?Classes