<html>
    <body>
        <table>
            <tr>
                <td> ID </td><td> Nmae</td><td>Distance</td>
            </tr>
            @foreach ($jdata as $key => $row)
            <tr>
                <td>{{ $key }}</td>
                <td> {{ $row["name"]}}</td>
                <td> {{ $row["distance"]}}</td>
            </tr>
            @endforeach
        
            
        </table>
    </body>
</html>
