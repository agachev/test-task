<html>
    <body>
        <table>
            <tr>
                <td> ID </td><td> Nmae</td><td>Distance</td>
            </tr>
            <?php $__currentLoopData = $jdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key); ?></td>
                <td> <?php echo e($row["name"]); ?></td>
                <td> <?php echo e($row["distance"]); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            
        </table>
    </body>
</html>
<?php /**PATH /var/www/html/laravelapp/resources/views/first.blade.php ENDPATH**/ ?>